 
 <?php

if(isset($_GET['CheckLogin'])){
	$conn=new mysqli('localhost','root','','testsql');
	//$query = $conn -> query("INSERT INTO registration (email,password) VALUES ('".$_POST['Email']."', '".$_POST['Password']."')");
	$query = $conn -> query("SELECT * FROM registration WHERE email = '".$_POST['Email']."'");
	while($row = $query->fetch_assoc())
		$temp = $row['password'];
	echo json_encode(array( "data" => $temp));

}

?>